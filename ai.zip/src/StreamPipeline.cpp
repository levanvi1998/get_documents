#include "StreamPipeline.hpp"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <gst/webrtc/webrtc.h>
#include <glib-object.h> // Cần thiết cho g_object_get
#include <sstream>
#include <iostream>
#include <thread>
#include "nlohmann/json.hpp" 

// --- Utility Functions (WebRTC) ---

// Callback khi Offer SDP đã được tạo
static void on_offer_created(GstPromise* promise, StreamPipeline* self) {
    GstWebRTCSessionDescription* offer = NULL;
    const GstStructure* reply = gst_promise_get_reply(promise);
    
    gst_structure_get(reply, "offer", GST_TYPE_WEBRTC_SESSION_DESCRIPTION, &offer, NULL);
    if (!offer) {
        std::cerr << "Stream " << self->id_ << ": Error creating Offer SDP." << std::endl;
        return;
    }
    
    // 1. Set Offer SDP locally
    GstPromise* local_desc_promise = gst_promise_new();
    g_signal_emit_by_name(self->webrtcBin_, "set-local-description", offer, local_desc_promise);
    gst_promise_wait(local_desc_promise);
    gst_promise_unref(local_desc_promise);

    // 2. Send Offer SDP via Signaling Server
    gchar* sdp_string = gst_sdp_message_as_text(offer->sdp);
    
    nlohmann::json msg;
    msg["id"] = "start"; 
    msg["streamId"] = self->id_;
    msg["sdp"]["type"] = "offer";
    msg["sdp"]["sdp"] = sdp_string;
    
    self->signalingClient_->SendMessage(msg.dump());
    
    g_free(sdp_string);
    gst_webrtc_session_description_free(offer);
}


// --- StreamPipeline Class Implementation ---

StreamPipeline::StreamPipeline(int id, std::string url, InferenceEngine* engine, const AppConfig& config) 
    : id_(id), rtmpUrl_(url), engine_(engine), config_(config) {
    
    // Khởi tạo signaling client
    signalingClient_ = std::make_unique<WebRtcSignaling>(id, this, "ws://127.0.0.1:8080/webrtc");
}

StreamPipeline::~StreamPipeline() {
    Stop();
}

void StreamPipeline::Stop() {
    if (pipeline_) {
        gst_element_set_state(pipeline_, GST_STATE_NULL);
        gst_object_unref(pipeline_);
        pipeline_ = nullptr;
    }
    signalingClient_->Disconnect();
}

void StreamPipeline::Start() {
    // ... (logic tạo pipeline)
    std::stringstream ss;
    
    // --- 1. Input Source (H.264) ---
    ss << "rtmpsrc location=" << rtmpUrl_ << " ! flvdemux ! h264parse ! tee name=t ";

    std::string dec, conv_ai, enc;
    
    if (config_.backend == InferenceBackend::CPU) {
        dec = "avdec_h264";
        conv_ai = "videoconvert"; 
        enc = "x264enc tune=zerolatency bitrate=2000000"; 
    } else {
        dec = "nvh264dec"; 
        conv_ai = "videoconvert"; 
        enc = "nvh264enc bitrate=2000000 preset=low-latency-hp"; 
    }

    // --- 2. Branch AI (Decode -> RGB -> AppSink) ---
    ss << "t. ! queue max-size-buffers=1 leaky=downstream ! "
       << dec << " ! " << conv_ai << " ! video/x-raw,format=RGB,width=" 
       << config_.aiInputWidth << ",height=" << config_.aiInputHeight << " ! "
       << "appsink name=ai_sink emit-signals=true sync=false drop=true ";

    // --- 3. Branch S3 (Record original compressed stream - Zero Encoding cost) ---
    ss << "t. ! queue ! splitmuxsink location=/tmp/rec_" << id_ << "_%05d.mp4 max-size-time=10000000000 ";

    // --- 4. Branch WebRTC (Re-encode for optimal bitrate) ---
    ss << "t. ! queue ! " << dec << " ! " 
       << "videoconvert ! " 
       << enc << " ! " 
       << "rtph264pay ! application/x-rtp,media=video,encoding-name=H264,payload=96 ! "
       << "webrtcbin name=webrtc_node bundle-policy=max-bundle ";
    // ... (end logic tạo pipeline)
    
    GError* err = nullptr;
    pipeline_ = gst_parse_launch(ss.str().c_str(), &err);
    if (err) {
        std::cerr << "Stream " << id_ << ": Pipeline creation error: " << err->message << std::endl;
        return;
    }
    
    webrtcBin_ = gst_bin_get_by_name(GST_BIN(pipeline_), "webrtc_node");

    GstBus* bus = gst_element_get_bus(pipeline_);
    gst_bus_add_watch(bus, (GstBusFunc)OnBusMessage, this);
    gst_object_unref(bus);

    GstElement* aiSink = gst_bin_get_by_name(GST_BIN(pipeline_), "ai_sink");
    g_signal_connect(aiSink, "new-sample", G_CALLBACK(OnNewSample), this);
    gst_object_unref(aiSink);

    // Setup WebRTC Callbacks
    g_signal_connect(webrtcBin_, "on-negotiation-needed", G_CALLBACK(OnNegotiationNeeded), this);
    g_signal_connect(webrtcBin_, "on-ice-candidate", G_CALLBACK(OnIceCandidate), this);
    g_signal_connect(webrtcBin_, "on-ice-gathering-state", G_CALLBACK(OnIceGatheringState), this);
    g_signal_connect(webrtcBin_, "on-data-channel", G_CALLBACK(OnDataChannel), this);

    // Create a data channel named 'metadata-channel' from the server side
    GstWebRTCDataChannel* channel_temp = nullptr;
    g_signal_emit_by_name(webrtcBin_, "create-data-channel", "metadata-channel", NULL, &channel_temp);
    if (channel_temp) {
        std::cout << "Stream " << id_ << ": Data Channel 'metadata-channel' created." << std::endl;
        g_object_unref(channel_temp); 
    } else {
        std::cerr << "Stream " << id_ << ": Failed to create Data Channel." << std::endl;
    }
    
    signalingClient_->Connect();

    gst_element_set_state(pipeline_, GST_STATE_PLAYING);
    std::cout << "Stream " << id_ << " started: " << rtmpUrl_ << std::endl;
}

// --- GStreamer Callbacks ---

GstFlowReturn StreamPipeline::OnNewSample(GstElement* sink, StreamPipeline* self) {
    GstSample* sample = gst_base_sink_get_last_sample(GST_BASE_SINK(sink));
    if (!sample) return GST_FLOW_ERROR;

    // ... (logic map buffer và gửi cho AI Engine)
    GstBuffer* buffer = gst_sample_get_buffer(sample);
    GstCaps* caps = gst_sample_get_caps(sample);
    GstStructure* s = gst_caps_get_structure(caps, 0);
    int w = 0, h = 0;
    gst_structure_get_int(s, "width", &w);
    gst_structure_get_int(s, "height", &h);

    GstMapInfo map;
    if (gst_buffer_map(buffer, &map, GST_MAP_READ)) {
        std::vector<uint8_t> frameData(map.data, map.data + map.size);
        
        auto future = self->engine_->SubmitFrame(self->id_, frameData, w, h);

        std::thread([self, f = std::move(future)]() mutable {
            try {
                std::string meta = f.get(); 
                self->SendMetadataToWebRTC(meta);
            } catch (const std::exception& e) {
                std::cerr << "Stream " << self->id_ << " AI Future Error: " << e.what() << std::endl;
            }
        }).detach();

        gst_buffer_unmap(buffer, &map);
    }
    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

gboolean StreamPipeline::OnBusMessage(GstBus* bus, GstMessage* msg, StreamPipeline* self) {
    // ... (logic xử lý tin nhắn Bus)
    switch (GST_MESSAGE_TYPE(msg)) {
    case GST_MESSAGE_ERROR: {
        GError *err = nullptr;
        gchar *debug_info = nullptr;
        gst_message_parse_error(msg, &err, &debug_info);
        std::cerr << "Stream " << self->id_ << " Error received from element " 
                  << GST_OBJECT_NAME(msg->src) << ": " << err->message << std::endl;
        g_clear_error(&err);
        g_free(debug_info);
        self->Stop(); 
        break;
    }
    case GST_MESSAGE_EOS:
        std::cout << "Stream " << self->id_ << " End-Of-Stream reached." << std::endl;
        self->Stop(); 
        break;
    default:
        break;
    }
    return TRUE;
}

// --- WebRTC Signaling Callbacks ---

void StreamPipeline::OnNegotiationNeeded(GstElement* webrtcbin, StreamPipeline* self) {
    std::cout << "Stream " << self->id_ << ": Negotiation Needed. Creating Offer..." << std::endl;
    
    GstPromise* promise = gst_promise_new_with_change_func((GstPromiseChangeFunc)on_offer_created, self, NULL);
    g_signal_emit_by_name(webrtcbin, "create-offer", NULL, promise);
}

void StreamPipeline::OnIceCandidate(GstElement* webrtcbin, guint mline_index, gchar* candidate, StreamPipeline* self) {
    nlohmann::json msg;
    msg["id"] = "iceCandidate";
    msg["streamId"] = self->id_;
    msg["candidate"]["candidate"] = candidate;
    msg["candidate"]["sdpMLineIndex"] = mline_index;
    
    self->signalingClient_->SendMessage(msg.dump());
}

void StreamPipeline::OnIceGatheringState(GstElement* webrtcbin, guint state, StreamPipeline* self) {
    // ... (logic log trạng thái)
    std::string state_str;
    switch (state) {
        case GST_WEBRTC_ICE_GATHERING_STATE_NEW: state_str = "NEW"; break;
        case GST_WEBRTC_ICE_GATHERING_STATE_GATHERING: state_str = "GATHERING"; break;
        case GST_WEBRTC_ICE_GATHERING_STATE_COMPLETE: state_str = "COMPLETE"; break;
        default: state_str = "UNKNOWN"; break;
    }
    std::cout << "Stream " << self->id_ << ": ICE Gathering State changed to " << state_str << std::endl;
}

void StreamPipeline::OnDataChannel(GstElement* webrtcbin, GstWebRTCDataChannel* channel, StreamPipeline* self) {
    self->dataChannel_ = channel; 
    
    // SỬA LỖI: Dùng g_object_get và gst_webrtc_data_channel_state_get_name
    gchar* label = NULL;
    GstWebRTCDataChannelState state = GST_WEBRTC_DATA_CHANNEL_STATE_OPEN;
    
    g_object_get(G_OBJECT(channel), 
                 "label", &label, 
                 "ready-state", &state, 
                 NULL);

    std::cout << "Stream " << self->id_ << ": Data Channel '" << (label ? label : "Unknown") << std::endl;
            //   << "' established. State: " << gst_webrtc_data_channel_state_get_name(state) << std::endl;
    
    if (label) g_free(label);
}

// --- Metadata Sender ---

void StreamPipeline::SendMetadataToWebRTC(const std::string& json) {
    GstWebRTCDataChannelState state = GST_WEBRTC_DATA_CHANNEL_STATE_CLOSED;
    
    // Lấy trạng thái Data Channel bằng g_object_get
    if (webrtcBin_ && dataChannel_) {
        g_object_get(G_OBJECT(dataChannel_), "ready-state", &state, NULL);
    }
    
    if (state == GST_WEBRTC_DATA_CHANNEL_STATE_OPEN) {
        // SỬA LỖI: gst_webrtc_data_channel_send_string trả về VOID trong một số API
        gst_webrtc_data_channel_send_string(dataChannel_, json.c_str());
    } else {
         // Log lỗi nếu kênh chưa sẵn sàng
         std::cerr << "Stream " << id_ << ": Failed to send metadata. Data Channel not open (State: " << std::endl;
                //    << gst_webrtc_data_channel_state_get_name(state) << ")." << std::endl;
    }
}