#include "WebRtcSignaling.hpp"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <boost/url/parse.hpp>

// --- THƯ VIỆN BÊN NGOÀI: nlohmann/json ---
#include "nlohmann/json.hpp" 

namespace net = boost::asio;
namespace beast = boost::beast;
namespace ws = beast::websocket;
using tcp = net::ip::tcp;

// --- Helper function to parse URL (required to separate host, port, target) ---
static bool ParseSignalingUrl(const std::string& url, std::string& host, std::string& port, std::string& target) {
    try {
        auto u = boost::urls::parse_uri(url);
        if (u.has_error()) return false;
        
        host = u->host_address();
        port = u->scheme_id() == boost::urls::scheme::wss ? "443" : "80"; // Basic port check
        if (!u->port().empty()) port = u->port();
        
        target = u->resource();
        if (target.empty()) target = "/";
        
        return true;
    } catch (...) {
        return false;
    }
}

// ----------------------------------------------------------------------------
// --- Public Methods ---
// ----------------------------------------------------------------------------

WebRtcSignaling::WebRtcSignaling(int streamId, StreamPipeline* pipeline, const std::string& signalingServerUrl)
    : streamId_(streamId), pipeline_(pipeline), ws_(ioc_) {
    
    if (!ParseSignalingUrl(signalingServerUrl, signalingHost_, signalingPort_, signalingTarget_)) {
        std::cerr << "[Signaling] Error parsing URL: " << signalingServerUrl << std::endl;
    }
    std::cout << "[Signaling] Initialized for Host: " << signalingHost_ << ", Port: " << signalingPort_ << std::endl;
}

WebRtcSignaling::~WebRtcSignaling() {
    Disconnect();
}

void WebRtcSignaling::Connect() {
    resolver_ = std::make_unique<tcp::resolver>(ioc_);
    
    // Run the io_context on a separate thread
    ioThread_ = std::thread(&WebRtcSignaling::RunIOLoop, this);

    // Start name resolution
    resolver_->async_resolve(signalingHost_, signalingPort_, 
        beast::bind_front_handler(&WebRtcSignaling::OnConnect, this));
}

void WebRtcSignaling::Disconnect() {
    if (!connected_) return;
    
    connected_ = false;
    
    // Stop io_context and close socket
    beast::error_code ec;
    ws_.close(ws::close_code::normal, ec);
    ioc_.stop(); 

    if (ioThread_.joinable()) {
        ioThread_.join();
    }
    std::cout << "[Signaling] WebSocket disconnected and I/O thread stopped." << std::endl;
}

void WebRtcSignaling::SendMessage(const std::string& message) {
    if (!connected_) return;

    // Use Strand/Post to ensure thread-safe writing from external threads (like GStreamer callbacks)
    net::post(ioc_, [this, message] {
        if (!connected_) return;
        
        // If the queue is empty, we are not currently writing, so start a new write operation.
        if (writeQueue_.empty()) {
            DoWrite(message);
        }
        // Always push the message to the queue
        writeQueue_.push_back(message);
    });
}

// ----------------------------------------------------------------------------
// --- Asynchronous I/O Handlers (Boost.Beast) ---
// ----------------------------------------------------------------------------

void WebRtcSignaling::RunIOLoop() {
    try {
        ioc_.run();
    } catch (const std::exception& e) {
        std::cerr << "[Signaling Thread] I/O Loop Exception: " << e.what() << std::endl;
    }
}

void WebRtcSignaling::OnConnect(const boost::system::error_code& ec, const tcp::resolver::results_type::endpoint_type& ep) {
    if (ec) {
        std::cerr << "[Signaling] Resolve failed: " << ec.message() << std::endl;
        return;
    }

    // Connect the socket to the resolved endpoint
    ws_.next_layer().async_connect(ep, 
        beast::bind_front_handler(&WebRtcSignaling::OnHandshake, this));
}

void WebRtcSignaling::OnHandshake(const boost::system::error_code& ec) {
    if (ec) {
        std::cerr << "[Signaling] Connect failed: " << ec.message() << std::endl;
        return;
    }

    // Perform the WebSocket handshake
    ws_.async_handshake(signalingHost_, signalingTarget_, 
        beast::bind_front_handler(&WebRtcSignaling::OnRead, this, beast::error_code{}, 0)); // Start read loop on success
    
    // *Actual Handshake Success Handling*
    connected_ = true;
    std::cout << "[Signaling] WebSocket Handshake successful. Registering stream." << std::endl;
    
    // Send initial registration message
    nlohmann::json msg;
    msg["id"] = "register";
    msg["streamId"] = streamId_;
    SendMessage(msg.dump());
}

void WebRtcSignaling::DoRead() {
    // Read a message into the buffer
    ws_.async_read(buffer_, 
        beast::bind_front_handler(&WebRtcSignaling::OnRead, this));
}

void WebRtcSignaling::OnRead(const boost::system::error_code& ec, std::size_t bytes_transferred) {
    if (!connected_) return;

    if (ec == ws::error::closed) {
        std::cerr << "[Signaling] WebSocket closed by peer." << std::endl;
        return;
    }
    if (ec) {
        std::cerr << "[Signaling] Read error: " << ec.message() << std::endl;
        return;
    }

    // Process the received message
    std::string message = beast::buffers_to_string(buffer_.data());
    
    // Call the synchronous handler (safe since it's on the I/O thread)
    HandleIncomingMessage(message);

    // Consume the buffer and restart the read loop
    buffer_.consume(buffer_.size());
    DoRead();
}

void WebRtcSignaling::DoWrite(const std::string& message) {
    // If a write is already in progress (queue is not empty), the message is already queued.
    // If the queue is empty, this is the first message. Push it and start writing.
    if (writeQueue_.empty()) {
        // This should not happen if called correctly from SendMessage, but safety first.
        return;
    }
    
    // Get the front message (the one that should be sent now)
    const std::string& msg = writeQueue_.front();
    
    // Write the message asynchronously
    ws_.async_write(net::buffer(msg), 
        beast::bind_front_handler(&WebRtcSignaling::OnWrite, this));
}

void WebRtcSignaling::OnWrite(const boost::system::error_code& ec, std::size_t bytes_transferred) {
    if (!connected_) return;

    if (ec) {
        std::cerr << "[Signaling] Write error: " << ec.message() << std::endl;
        writeQueue_.clear(); // Clear queue on error
        return;
    }

    // Remove the message we just successfully sent
    writeQueue_.pop_front();
    
    // If there are more messages in the queue, start the next write operation
    if (!writeQueue_.empty()) {
        DoWrite(writeQueue_.front());
    }
}

// ----------------------------------------------------------------------------
// --- Synchronous Signal Handler (Called by I/O thread) ---
// ----------------------------------------------------------------------------

void WebRtcSignaling::HandleIncomingMessage(const std::string& message) {
    if (pipeline_->pipeline_ == nullptr) return;

    try {
        nlohmann::json msg = nlohmann::json::parse(message);
        
        // --- 1. Handle Answer SDP ---
        if (msg.contains("sdp") && msg["sdp"]["type"] == "answer") {
            // ... (SDP parsing logic)
            std::string sdp_string = msg["sdp"]["sdp"].get<std::string>();
            
            GstSDPMessage* sdp;
            if (gst_sdp_message_new_from_text(&sdp, sdp_string.c_str()) != GST_SDP_OK) {
                std::cerr << "Stream " << streamId_ << " Error: Failed to parse Answer SDP." << std::endl;
                return;
            }
            
            GstWebRTCSessionDescription* answer = gst_webrtc_session_description_new(GST_WEBRTC_SDP_TYPE_ANSWER, sdp);
            
            // Set Remote Description (using GStreamer's thread)
            // Use post on GStreamer's main context if the pipeline is actively manipulated outside of its threads.
            GstPromise* promise = gst_promise_new();
            g_signal_emit_by_name(pipeline_->webrtcBin_, "set-remote-description", answer, promise);
            gst_promise_wait(promise);
            gst_promise_unref(promise);

            std::cout << "Stream " << streamId_ << ": Received and set Answer SDP." << std::endl;
            gst_webrtc_session_description_free(answer);
        } 
        
        // --- 2. Handle ICE Candidate ---
        else if (msg.contains("candidate") && msg.contains("id") && msg["id"] == "iceCandidate") {
            std::string candidate = msg["candidate"]["candidate"].get<std::string>();
            guint mline_index = msg["candidate"]["sdpMLineIndex"].get<guint>();
            
            // Add ICE Candidate (using GStreamer's thread)
            g_signal_emit_by_name(pipeline_->webrtcBin_, "add-ice-candidate", mline_index, candidate.c_str());
        } 
        
        // --- 3. Handle 'start' command from Client (to initiate Offer) ---
        else if (msg.contains("id") && msg["id"] == "start") {
             std::cout << "Stream " << streamId_ << ": Received 'start' command from Client. Initiating Negotiation..." << std::endl;
             // Trigger negotiation (this is safe as it just emits a signal)
             g_signal_emit_by_name(pipeline_->webrtcBin_, "on-negotiation-needed");
        }
        
    } catch (const nlohmann::json::parse_error& e) {
        std::cerr << "Stream " << streamId_ << " JSON Parsing Error from Signaling Server: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Stream " << streamId_ << " Signaling Message Handling Error: " << e.what() << std::endl;
    }
}