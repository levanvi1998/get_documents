#include "Config.hpp"
#include "InferenceEngine.hpp"
#include "StreamPipeline.hpp"
#include <vector>
#include <memory>
#include <iostream>

// Hàm giả lập HTTP Setup Stream
void SetupMockStreams(std::vector<std::unique_ptr<StreamPipeline>>& streams, InferenceEngine* engine, const AppConfig& config) {
    std::cout << "--- Setting up streams (Mock HTTP Setup) ---" << std::endl;
    
    // Yêu cầu 1: Stream từ RTMP nguồn 1
    std::string url1 = "rtmp://127.0.0.1/live/cam1";
    std::cout << "Adding Stream 1: " << url1 << std::endl;
    auto s1 = std::make_unique<StreamPipeline>(1, url1, engine, config);
    s1->Start();
    streams.push_back(std::move(s1));

    // Yêu cầu 2: Stream từ RTMP nguồn 2
    std::string url2 = "rtmp://127.0.0.1/live/cam2";
    std::cout << "Adding Stream 2: " << url2 << std::endl;
    auto s2 = std::make_unique<StreamPipeline>(2, url2, engine, config);
    s2->Start();
    streams.push_back(std::move(s2));

    std::cout << "--- Stream setup complete ---" << std::endl;
}

int main(int argc, char* argv[]) {
    // Khởi tạo GStreamer
    gst_init(&argc, &argv);

    // 1. Load Config
    AppConfig config;
    // Chỉnh sửa config tại đây nếu cần:
    // config.backend = InferenceBackend::CPU; 
    
    // 2. Khởi tạo AI Engine (Dùng chung cho tất cả các luồng)
    InferenceEngine aiEngine(config);

    // 3. Quản lý các Stream
    std::vector<std::unique_ptr<StreamPipeline>> streams;
    SetupMockStreams(streams, &aiEngine, config);

    // Giữ main loop chạy để GStreamer bus và WebRTC hoạt động
    GMainLoop* loop = g_main_loop_new(NULL, FALSE);
    std::cout << "\nServer running. Press Ctrl+C to stop." << std::endl;
    g_main_loop_run(loop);

    // Cleanup
    streams.clear(); 
    g_main_loop_unref(loop);
    
    std::cout << "Server stopped." << std::endl;
    return 0;
}