#include "InferenceEngine.hpp"
#include <iostream>
#include <chrono>
#include <numeric>
#include <algorithm>
#include <cmath>

#ifdef _MSC_VER
#include <intrin.h> // SIMD for Windows (Not used here, just note)
#endif
// Cần thiết cho CUDA allocation/copy khi dùng GPU (nếu dùng TensorRT provider thì ít cần hơn)
#include <cuda_runtime.h> 

InferenceEngine::InferenceEngine(const AppConfig& config) 
    : config_(config), env_(ORT_LOGGING_LEVEL_WARNING, "YOLO_Service") {
    
    Ort::SessionOptions sessionOptions;
    sessionOptions.SetIntraOpNumThreads(1);
    sessionOptions.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);

    // 1. Cấu hình Execution Provider (TensorRT -> CUDA -> CPU)
    try {
        if (config.backend == InferenceBackend::TENSORRT) {
            std::cout << "[AI] Using TensorRT Provider..." << std::endl;
            OrtTensorRTProviderOptions trt_opts{};
            trt_opts.device_id = config.gpuDeviceId;
            trt_opts.trt_fp16_enable = 1;
            trt_opts.trt_engine_cache_enable = 1; 
            sessionOptions.AppendExecutionProvider_TensorRT(trt_opts);
        } else if (config.backend == InferenceBackend::CUDA) {
            std::cout << "[AI] Using CUDA Provider..." << std::endl;
            OrtCUDAProviderOptions cuda_opts{};
            cuda_opts.device_id = config.gpuDeviceId;
            sessionOptions.AppendExecutionProvider_CUDA(cuda_opts);
        }
    } catch (...) {
        std::cerr << "[Warning] GPU Provider setup failed. Falling back to CPU!" << std::endl;
    }

    session_ = Ort::Session(env_, config.modelPath.c_str(), sessionOptions);
    
    // Lấy tên input/output
    Ort::AllocatorWithDefaultOptions allocator;
    inputName_ = session_.GetInputNameAllocated(0, allocator).get();
    outputName_ = session_.GetOutputNameAllocated(0, allocator).get();

    // Khởi động thread xử lý batch
    workerThread_ = std::thread(&InferenceEngine::WorkerLoop, this);
}

InferenceEngine::~InferenceEngine() {
    running_ = false;
    queueCv_.notify_all();
    if (workerThread_.joinable()) workerThread_.join();
}

std::future<std::string> InferenceEngine::SubmitFrame(int streamId, const std::vector<uint8_t>& data, int w, int h) {
    auto req = std::make_unique<FrameRequest>();
    req->streamId = streamId;
    req->data = data; // Copy dữ liệu. Có thể tối ưu bằng Pinned Memory nếu cần
    req->width = w;
    req->height = h;
    
    auto future = req->promise.get_future();

    {
        std::lock_guard<std::mutex> lock(queueMutex_);
        queue_.push(std::move(req));
    }
    // Thông báo cho worker thread để nó check queue
    queueCv_.notify_one(); 
    return future;
}

void InferenceEngine::WorkerLoop() {
    std::vector<std::unique_ptr<FrameRequest>> batch;
    batch.reserve(config_.maxBatchSize);

    while (running_) {
        std::unique_lock<std::mutex> lock(queueMutex_);
        
        // Dynamic Batching Logic: Chờ hoặc đủ Batch hoặc hết thời gian timeout
        queueCv_.wait_for(lock, std::chrono::milliseconds(config_.batchTimeoutMs), [this] {
            return !running_ || queue_.size() >= config_.maxBatchSize;
        });

        if (!running_ && queue_.empty()) break;

        // Lấy frame ra khỏi hàng đợi
        while (!queue_.empty() && batch.size() < config_.maxBatchSize) {
            batch.push_back(std::move(queue_.front()));
            queue_.pop();
        }
        lock.unlock();

        if (!batch.empty()) {
            ProcessBatch(batch);
            batch.clear();
        }
    }
}

/**
 * @brief Gom batch và chạy Inference.
 */
void InferenceEngine::ProcessBatch(std::vector<std::unique_ptr<FrameRequest>>& batch) {
    const int B = batch.size();
    const int C = 3; 
    const int H = config_.aiInputHeight; 
    const int W = config_.aiInputWidth;
    const size_t InputTensorSize = static_cast<size_t>(B) * C * H * W;

    // 1. Phân bổ Bộ nhớ Host để tiền xử lý
    std::vector<float> hostBatchData(InputTensorSize); 

    // 2. Tiền xử lý & Gom Batch (HWC -> CHW, Normalize)
    for (int i = 0; i < B; ++i) {
        const auto& req = batch[i];
        const uint8_t* rawData = req->data.data();
        float* framePtr = hostBatchData.data() + static_cast<size_t>(i) * C * H * W;

        for (int c = 0; c < C; ++c) {
            for (int h = 0; h < H; ++h) {
                for (int w = 0; w < W; ++w) {
                    int rawIndex = (h * W + w) * C + c;
                    int outputIndex = c * H * W + h * W + w;
                    framePtr[outputIndex] = static_cast<float>(rawData[rawIndex]) / 255.0f;
                }
            }
        }
    }

    // 3. Chuẩn bị Input Tensor trực tiếp
    Ort::MemoryInfo memoryInfo = Ort::MemoryInfo::CreateCpu(
        OrtAllocatorType::OrtArenaAllocator, OrtMemTypeDefault);

    std::vector<int64_t> inputShape = {static_cast<int64_t>(B), C, H, W};

    Ort::Value inputTensor = Ort::Value::CreateTensor<float>(
        memoryInfo,
        hostBatchData.data(),
        InputTensorSize,
        inputShape.data(),
        inputShape.size()
    );

    // 4. Run Inference
    std::vector<const char*> inputNames = {inputName_.c_str()};
    std::vector<const char*> outputNames = {outputName_.c_str()};

    auto outputTensors = session_.Run(
        Ort::RunOptions{nullptr},
        inputNames.data(),
        &inputTensor,
        1,
        outputNames.data(),
        1
    );

    // 5. Hậu xử lý & Trả kết quả
    for (int i = 0; i < B; ++i) {
        std::string mockMetadata = "{ \"stream_id\": " + std::to_string(batch[i]->streamId) + 
                                   ", \"timestamp\": \"" + std::to_string(std::time(0)) + "\""
                                   ", \"detections\": [ { \"box\": [150, 150, 300, 300], \"label\": \"person\" } ] }";
        batch[i]->promise.set_value(mockMetadata);
    }
}
