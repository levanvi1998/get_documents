#pragma once
#include <string>
#include <vector>

enum class InferenceBackend {
    CPU,
    CUDA,
    TENSORRT
};

struct AppConfig {
    // Cấu hình AI
    InferenceBackend backend = InferenceBackend::TENSORRT; // Ưu tiên TensorRT
    int gpuDeviceId = 0;
    std::string modelPath = "yolo11.onnx";
    
    // Dynamic Batching
    int maxBatchSize = 8;        // Gom tối đa 8 frame
    int batchTimeoutMs = 15;     // Thời gian chờ tối đa để gom batch
    
    // Input Video Specs (YOLOv8/11 default)
    int aiInputWidth = 640;
    int aiInputHeight = 640;

    // S3 Settings
    // (Trong code mẫu này, ta không thực hiện upload S3 thực tế, nhưng giữ config)
    std::string s3Bucket = "my-video-archive";
};