#pragma once
#include "Config.hpp"
#include <onnxruntime_cxx_api.h>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <future>
#include <memory>
#include <map>

// Cấu trúc dữ liệu cho 1 request inference
struct FrameRequest {
    int streamId;
    std::vector<uint8_t> data; // Dữ liệu ảnh Raw (RGB)
    int width, height;
    std::promise<std::string> promise; // Để trả kết quả metadata về (JSON)
};

class InferenceEngine {
public:
    InferenceEngine(const AppConfig& config);
    ~InferenceEngine();

    // Hàm nhận frame từ GStreamer (Thread-safe)
    std::future<std::string> SubmitFrame(int streamId, const std::vector<uint8_t>& data, int w, int h);
    
private:
    void WorkerLoop();
    void ProcessBatch(std::vector<std::unique_ptr<FrameRequest>>& batch);

    AppConfig config_;
    Ort::Env env_;
    Ort::Session session_{nullptr};
    
    // Queue quản lý batch
    std::queue<std::unique_ptr<FrameRequest>> queue_;
    std::mutex queueMutex_;
    std::condition_variable queueCv_;
    
    std::thread workerThread_;
    bool running_ = true;

    // Tên input/output của model
    std::string inputName_;
    std::string outputName_;
};