#pragma once
#include <gst/gst.h>
#include <gst/webrtc/webrtc.h> // Chứa GstWebRTCIceGatheringState và GstWebRTCDataChannelState
#include <string>
#include <memory>
#include "InferenceEngine.hpp"
#include "WebRtcSignaling.hpp"
#include "Config.hpp"

// Forward declarations
class InferenceEngine;
class WebRtcSignaling;

class StreamPipeline {
public:
    StreamPipeline(int id, std::string url, InferenceEngine* engine, const AppConfig& config);
    ~StreamPipeline();

    void Start();
    void Stop();

    // Các thành viên public cần thiết cho WebRtcSignaling.cpp để truy cập GStreamer
    GstElement* webrtcBin_ = nullptr;
    GstWebRTCDataChannel* dataChannel_ = nullptr;
    int id_;

private:
    // --- Core GStreamer Callbacks ---
    static GstFlowReturn OnNewSample(GstElement* sink, StreamPipeline* self);
    static gboolean OnBusMessage(GstBus* bus, GstMessage* msg, StreamPipeline* self);
    
    // --- WebRTC Signaling Callbacks ---
    static void on_offer_created(GstPromise* promise, StreamPipeline* self);
    static void OnNegotiationNeeded(GstElement* webrtcbin, StreamPipeline* self);
    static void OnIceCandidate(GstElement* webrtcbin, guint mline_index, gchar* candidate, StreamPipeline* self);
    static void OnDataChannel(GstElement* webrtcbin, GstWebRTCDataChannel* channel, StreamPipeline* self);
    static void OnIceGatheringState(GstElement* webrtcbin, guint state, StreamPipeline* self);

    // --- Metadata Sender ---
    void SendMetadataToWebRTC(const std::string& json);
    
    // --- Thành viên dữ liệu ---
    std::string rtmpUrl_;
    InferenceEngine* engine_;
    AppConfig config_;

    
public:
    GstElement* pipeline_ = nullptr;
    std::unique_ptr<WebRtcSignaling> signalingClient_;
};