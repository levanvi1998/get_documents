#pragma once
#include <string>
#include <functional>
#include <memory>
#include <iostream>
#include <thread>
#include "StreamPipeline.hpp" 
#include "Config.hpp"        

// --- Boost Headers ---
#include <boost/asio.hpp>
#include <boost/beast.hpp>

// Forward declaration
class StreamPipeline;

namespace net = boost::asio;
namespace beast = boost::beast;
namespace ws = beast::websocket;
using tcp = net::ip::tcp;

/**
 * @brief Manages the WebSocket connection for WebRTC Signaling using Boost.Beast.
 */
class WebRtcSignaling {
public:
    WebRtcSignaling(int streamId, StreamPipeline* pipeline, const std::string& signalingServerUrl);
    ~WebRtcSignaling();

    void Connect(); 
    void Disconnect();

    // Thread-safe method to send messages (called from GStreamer callbacks)
    void SendMessage(const std::string& message);

    // Method called by the WebSocket loop when data is received (to process SDP/ICE)
    void HandleIncomingMessage(const std::string& message);

private:
    void RunIOLoop();
    void OnConnect(const boost::system::error_code& ec, const tcp::resolver::results_type::endpoint_type& ep);
    void OnHandshake(const boost::system::error_code& ec);
    void DoRead();
    void OnRead(const boost::system::error_code& ec, std::size_t bytes_transferred);
    void DoWrite(const std::string& message);
    void OnWrite(const boost::system::error_code& ec, std::size_t bytes_transferred);

private:
    int streamId_;
    std::string signalingHost_;
    std::string signalingPort_;
    std::string signalingTarget_;
    StreamPipeline* pipeline_;

    // --- Boost.ASIO/BEAST Members ---
    net::io_context ioc_;
    std::unique_ptr<tcp::resolver> resolver_;
    ws::stream<tcp::socket> ws_;
    
    // Buffer for reading incoming messages
    beast::flat_buffer buffer_;
    
    // Mutex for thread-safe message queue access
    std::mutex writeMutex_; 
    std::deque<std::string> writeQueue_;

    // Thread running the io_context
    std::thread ioThread_; 
    bool connected_ = false;
};