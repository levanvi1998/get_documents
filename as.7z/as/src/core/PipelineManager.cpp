#include "PipelineManager.h"

PipelineManager::PipelineManager(std::shared_ptr<AIEngine> ai,
                                 std::shared_ptr<WebSocketServer> ws,
                                 std::shared_ptr<S3Uploader> s3)
: ai_(ai), ws_(ws), s3_(s3) {}

PipelineManager::~PipelineManager() {
    std::lock_guard<std::mutex> lk(mux_);
    for (auto &p : sessions_) p.second->stop();
    sessions_.clear();
}

bool PipelineManager::startStream(const std::string& id, const std::string& uri) {
    std::lock_guard<std::mutex> lk(mux_);
    if (sessions_.count(id)) return false;
    auto s = std::make_shared<StreamSession>(id, uri, ai_, ws_, s3_);
    sessions_.emplace(id, s);
    s->start();
    return true;
}

bool PipelineManager::stopStream(const std::string& id) {
    std::lock_guard<std::mutex> lk(mux_);
    auto it = sessions_.find(id);
    if (it == sessions_.end()) return false;
    it->second->stop();
    sessions_.erase(it);
    return true;
}

std::vector<std::string> PipelineManager::listStreams() {
    std::lock_guard<std::mutex> lk(mux_);
    std::vector<std::string> out;
    for (auto &p : sessions_) out.push_back(p.first);
    return out;
}
