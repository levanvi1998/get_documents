#include "StreamSession.h"
#include <nlohmann/json.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>

using json = nlohmann::json;

StreamSession::StreamSession(const std::string& id,
                             const std::string& uri,
                             std::shared_ptr<AIEngine> ai,
                             std::shared_ptr<AsyncWsServer> ws,
                             std::shared_ptr<S3Uploader> s3)
: id_(id), uri_(uri), ai_(ai), ws_(ws), s3_(s3)
{
    recorder_ = std::make_shared<Recorder>(id_, s3_);

    // create pipeline with segment callback bound to recorder:
    pipeline_ = std::make_unique<GStreamerPipeline>(uri_, queue_, [rec=recorder_](const std::string& path){
        rec->onSegmentReady(path);
    });
}

StreamSession::~StreamSession() { stop(); }

void StreamSession::start() {
    if (running_) return;
    running_ = true;
    pipeline_->start();
    th_ = std::thread(&StreamSession::workerLoop, this);
    std::cout << "StreamSession started: " << id_ << std::endl;
}

void StreamSession::stop() {
    if (!running_) return;
    running_ = false;
    pipeline_->stop();
    queue_.clear();
    if (th_.joinable()) th_.join();
    std::cout << "StreamSession stopped: " << id_ << std::endl;
}

void StreamSession::workerLoop() {
    while (running_) {
        FrameItem fi;
        if (!queue_.pop(fi, 1000)) continue;
        // convert to cv::Mat (BGR)
        cv::Mat img(fi.height, fi.width, CV_8UC3, fi.data.data());
        cv::Mat input;
        img.copyTo(input); // ensure ownership

        // infer
        json meta = ai_->infer(input);
        meta["stream"] = id_;
        meta["pts"] = fi.pts;
        meta["ts_ms"] = (long long)std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

        // broadcast to WS
        // if (ws_) ws_->broadcast(meta.dump());
        if(ws_)
        {
            ws_->publish(id_, meta.dump());
        }

        // append metadata locally + upload later via s3_
        if (s3_) {
            s3_->appendMetadata(id_, meta.dump()); // we'll implement appendMetadata
        }
    }
}
