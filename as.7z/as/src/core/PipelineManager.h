#pragma once
#include <unordered_map>
#include <memory>
#include <mutex>
#include "../ai/AIEngine.h"
#include "../ws/WebSocketServer.h"
#include "../aws/S3Uploader.h"
#include "StreamSession.h"

class PipelineManager {
public:
    PipelineManager(std::shared_ptr<AIEngine> ai,
                    std::shared_ptr<WebSocketServer> ws,
                    std::shared_ptr<S3Uploader> s3);
    ~PipelineManager();

    bool startStream(const std::string& id, const std::string& uri);
    bool stopStream(const std::string& id);
    std::vector<std::string> listStreams();

private:
    std::unordered_map<std::string, std::shared_ptr<StreamSession>> sessions_;
    std::mutex mux_;
    std::shared_ptr<AIEngine> ai_;
    std::shared_ptr<WebSocketServer> ws_;
    std::shared_ptr<S3Uploader> s3_;
};
