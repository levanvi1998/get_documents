#pragma once
#include <string>
#include <memory>
#include <atomic>
#include <thread>
#include "util/ThreadSafeQueue.h"
#include "pipeline/GStreamerPipeline.h"
#include "ai/AIEngine.h"
#include "ws/AsyncWsServer.h"
#include "aws/S3Uploader.h"
#include "pipeline/Recorder.h"

class StreamSession {
public:
    StreamSession(const std::string& id,
                  const std::string& uri,
                  std::shared_ptr<AIEngine> ai,
                  std::shared_ptr<AsyncWsServer> ws,
                  std::shared_ptr<S3Uploader> s3);
    ~StreamSession();

    void start();
    void stop();
    bool isRunning() const { return running_; }

private:
    void workerLoop();

    std::string id_;
    std::string uri_;
    std::shared_ptr<AIEngine> ai_;
    std::shared_ptr<AsyncWsServer> ws_;
    std::shared_ptr<S3Uploader> s3_;
    std::shared_ptr<Recorder> recorder_;

    ThreadSafeQueue<FrameItem> queue_;
    std::unique_ptr<GStreamerPipeline> pipeline_;
    std::atomic<bool> running_{false};
    std::thread th_;
};
