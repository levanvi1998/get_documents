#pragma once
#include <string>
#include <mutex>
#include <nlohmann/json.hpp>
#include <opencv2/opencv.hpp>
#include <onnxruntime_cxx_api.h>

class AIEngine {
public:
    AIEngine(const std::string& modelPath, int input_w = 640, int input_h = 640);
    ~AIEngine();

    // nhận frame BGR cv::Mat, trả về JSON string metadata
    nlohmann::json infer(const cv::Mat& bgr);

private:
    Ort::Env env_;
    Ort::SessionOptions opts_;
    std::unique_ptr<Ort::Session> session_;
    std::mutex run_mtx_;

    int input_w_, input_h_;
    std::vector<std::string> input_names_;
    std::vector<std::string> output_names_;

    std::vector<float> preprocess(const cv::Mat& img);
};
