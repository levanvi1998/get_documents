#include "AIEngine.h"
#include <iostream>

AIEngine::AIEngine(const std::string& modelPath, int input_w, int input_h)
: env_(ORT_LOGGING_LEVEL_WARNING, "ai"), input_w_(input_w), input_h_(input_h) {
    opts_.SetIntraOpNumThreads(1);
    opts_.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_BASIC);

    session_.reset(new Ort::Session(env_, modelPath.c_str(), opts_));
    Ort::AllocatorWithDefaultOptions allocator;
    size_t nInputs = session_->GetInputCount();
    for (size_t i=0;i<nInputs;i++){
        char* name = session_->GetInputName(i, allocator);
        input_names_.push_back(name);
        allocator.Free(name);
    }
    size_t nOutputs = session_->GetOutputCount();
    for (size_t i=0;i<nOutputs;i++){
        char* name = session_->GetOutputName(i, allocator);
        output_names_.push_back(name);
        allocator.Free(name);
    }
    std::cout << "AIEngine loaded model: " << modelPath << "\n";
}

AIEngine::~AIEngine(){}

std::vector<float> AIEngine::preprocess(const cv::Mat& img) {
    cv::Mat resized;
    cv::resize(img, resized, cv::Size(input_w_, input_h_));
    cv::Mat f;
    resized.convertTo(f, CV_32F, 1.0/255.0);
    // HWC -> CHW
    std::vector<float> tensor(3 * input_h_ * input_w_);
    for (int c=0;c<3;c++){
        for (int h=0; h<input_h_; h++){
            for (int w=0; w<input_w_; w++){
                tensor[c*input_h_*input_w_ + h*input_w_ + w] = f.at<cv::Vec3f>(h,w)[c];
            }
        }
    }
    return tensor;
}

nlohmann::json AIEngine::infer(const cv::Mat& bgr) {
    using json = nlohmann::json;
    std::lock_guard<std::mutex> lk(run_mtx_);

    // convert BGR -> RGB float tensor (many models expect RGB)
    cv::Mat rgb;
    cv::cvtColor(bgr, rgb, cv::COLOR_BGR2RGB);
    auto input_tensor = preprocess(rgb);
    std::array<int64_t,4> dims{1,3,input_h_,input_w_};

    Ort::MemoryInfo mem_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    Ort::Value in_tensor = Ort::Value::CreateTensor<float>(mem_info, input_tensor.data(), input_tensor.size(), dims.data(), dims.size());

    std::vector<const char*> in_names, out_names;
    for (auto &s: input_names_) in_names.push_back(s.c_str());
    for (auto &s: output_names_) out_names.push_back(s.c_str());

    auto outputs = session_->Run(Ort::RunOptions{nullptr}, in_names.data(), &in_tensor, 1, out_names.data(), out_names.size());

    // Basic generic postprocess: return output shapes + raw first elements
    json meta;
    meta["outputs"] = json::array();
    for (size_t i=0;i<outputs.size();++i){
        auto &ot = outputs[i];
        auto info = ot.GetTensorTypeAndShapeInfo();
        auto shape = info.GetShape();
        size_t cnt = info.GetElementCount();
        meta["outputs"][i]["shape"] = shape;
        meta["outputs"][i]["count"] = cnt;
        // copy first up to 10 floats
        try {
            float* ptr = ot.GetTensorMutableData<float>();
            size_t n = std::min<size_t>(10, cnt);
            std::vector<float> small(ptr, ptr + n);
            meta["outputs"][i]["first_values"] = small;
        } catch (...) {
            meta["outputs"][i]["first_values"] = json::array();
        }
    }

    // NOTE: THIS IS GENERIC. Replace with real postprocessing (e.g., decode YOLO + NMS)
    meta["note"] = "Generic output; implement model-specific decode/postprocess";
    return meta;
}
