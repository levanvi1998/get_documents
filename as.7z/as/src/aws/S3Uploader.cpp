#include "S3Uploader.h"
#include <iostream>
#include <filesystem>

#ifdef USE_AWS_SDK
#include <aws/core/Aws.h>
#include <aws/s3/S3Client.h>
#include <aws/s3/model/PutObjectRequest.h>
#endif

struct S3Uploader::Impl {
#ifdef USE_AWS_SDK
    std::shared_ptr<Aws::S3::S3Client> client;
#endif
};

S3Uploader::S3Uploader(const std::string& bucket, const std::string& region, bool enableAws)
: bucket_(bucket), region_(region), enabledAws_(enableAws)
{
    impl_ = new Impl();
#ifdef USE_AWS_SDK
    if (enabledAws_) {
        Aws::SDKOptions options;
        Aws::InitAPI(options);
        Aws::Client::ClientConfiguration config;
        config.region = region_;
        impl_->client = std::make_shared<Aws::S3::S3Client>(config);
        std::cout << "[S3Uploader] AWS SDK initialized region=" << region_ << std::endl;
    }
#else
    if (enabledAws_) {
        std::cerr << "[S3Uploader] compiled without AWS SDK - fallback to disabled\n";
        enabledAws_ = false;
    }
#endif
}

S3Uploader::~S3Uploader() {
#ifdef USE_AWS_SDK
    if (enabledAws_) {
        Aws::SDKOptions options;
        Aws::ShutdownAPI(options);
    }
#endif
    delete impl_;
}

bool S3Uploader::uploadFile(const std::string& localPath, const std::string& s3Key) {
    std::lock_guard<std::mutex> lk(mux_);
    if (!std::filesystem::exists(localPath)) {
        std::cerr << "[S3Uploader] local file not found: " << localPath << std::endl;
        return false;
    }

    if (!enabledAws_) {
        // Fallback: print and return false (or true if you want)
        std::cout << "[S3Uploader] AWS disabled — would upload " << localPath << " -> " << s3Key << std::endl;
        return false;
    }

#ifdef USE_AWS_SDK
    Aws::S3::Model::PutObjectRequest request;
    request.SetBucket(bucket_.c_str());
    request.SetKey(s3Key.c_str());

    auto input_data = Aws::MakeShared<Aws::FStream>("PutObjectInputStream", localPath.c_str(), std::ios::in | std::ios::binary);
    request.SetBody(input_data);

    auto outcome = impl_->client->PutObject(request);
    if (!outcome.IsSuccess()) {
        std::cerr << "[S3Uploader] PutObject failed: " << outcome.GetError().GetMessage() << std::endl;
        return false;
    }
    return true;
#else
    return false;
#endif
}
