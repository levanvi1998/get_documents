#pragma once
#include <string>
#include <mutex>

class S3Uploader {
public:
    S3Uploader(const std::string& bucket, const std::string& region, bool enableAws = true);
    ~S3Uploader();

    // Upload local file to S3 key. Returns true if success (or file exists and uploaded).
    bool uploadFile(const std::string& localPath, const std::string& s3Key);

private:
    std::string bucket_;
    std::string region_;
    bool enabledAws_;
    std::mutex mux_;

    // internal AWS client pointer hidden to avoid header leak (pimpl-like)
    struct Impl;
    Impl* impl_ = nullptr;
};
