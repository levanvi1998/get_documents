#include "AsyncWsServer.h"
#include <nlohmann/json.hpp>
#include <iostream>

using json = nlohmann::json;

/////////////////////////////////////////////////////////
// WsSession
WsSession::WsSession(tcp::socket socket, AsyncWsServer* server)
: ws_(std::move(socket)), server_(server) {
    ws_.binary(false);
}

std::string WsSession::id() {
    try {
        auto ep = ws_.next_layer().socket().remote_endpoint();
        return ep.address().to_string() + ":" + std::to_string(ep.port());
    } catch(...) { return "unknown"; }
}

void WsSession::start() {
    auto self = shared_from_this();
    ws_.async_accept([self](beast::error_code ec) {
        if (ec) {
            std::cerr << "ws accept error: " << ec.message() << std::endl;
            return;
        }
        self->read_loop();
    });
}

void WsSession::read_loop() {
    auto self = shared_from_this();
    ws_.async_read(buffer_, [self](beast::error_code ec, std::size_t bytes_transferred){
        self->on_read(ec, bytes_transferred);
    });
}

void WsSession::on_read(beast::error_code ec, std::size_t) {
    if (ec) {
        // connection closed or error -> cleanup subscriptions
        std::lock_guard<std::mutex> lk(write_mux_);
        for (auto &s : subscriptions_) server_->unsubscribe_client(s, shared_from_this());
        return;
    }
    std::string msg = beast::buffers_to_string(buffer_.data());
    buffer_.consume(buffer_.size());
    try {
        process_message(msg);
    } catch (std::exception &e) {
        std::cerr << "process_message error: " << e.what() << std::endl;
    }
    read_loop();
}

void WsSession::process_message(const std::string& s) {
    auto j = json::parse(s);
    std::string action = j.value("action", "");
    if (!authenticated_) {
        if (action != "auth") {
            // require auth first
            deliver(R"({"error":"auth_required"})");
            ws_.next_layer().close();
            return;
        }
        // std::string token = j.value("token", "");
        // if (token != server_->auth_secret_) { // simple check; in real use validate JWT
        //     deliver(R"({"error":"invalid_token"})");
        //     ws_.next_layer().close();
        //     return;
        // }
        authenticated_ = true;
        // initial subscriptions
        if (j.contains("subscribe")) {
            for (auto &id : j["subscribe"]) {
                std::string sid = id.get<std::string>();
                subscriptions_.insert(sid);
                server_->subscribe_client(sid, shared_from_this());
            }
        }
        deliver(R"({"ok":"authenticated"})");
        return;
    }

    if (action == "subscribe") {
        for (auto &id : j["streams"]) {
            std::string sid = id.get<std::string>();
            subscriptions_.insert(sid);
            server_->subscribe_client(sid, shared_from_this());
        }
        deliver(R"({"ok":"subscribed"})");
    } else if (action == "unsubscribe") {
        for (auto &id : j["streams"]) {
            std::string sid = id.get<std::string>();
            subscriptions_.erase(sid);
            server_->unsubscribe_client(sid, shared_from_this());
        }
        deliver(R"({"ok":"unsubscribed"})");
    } else {
        deliver(R"({"error":"unknown_action"})");
    }
}

void WsSession::deliver(const std::string& msg) {
    std::lock_guard<std::mutex> lk(write_mux_);
    bool write_in_progress = !write_q_.empty();
    write_q_.push_back(msg);
    if (!write_in_progress) write_next();
}

void WsSession::write_next() {
    auto self = shared_from_this();
    if (write_q_.empty()) return;
    ws_.async_write(net::buffer(write_q_.front()), [self](beast::error_code ec, std::size_t bytes_transferred){
        self->on_write(ec, bytes_transferred);
    });
}

void WsSession::on_write(beast::error_code ec, std::size_t) {
    std::lock_guard<std::mutex> lk(write_mux_);
    if (ec) {
        std::cerr << "ws write error: " << ec.message() << std::endl;
        // cleanup subscriptions
        for (auto &s : subscriptions_) server_->unsubscribe_client(s, shared_from_this());
        return;
    }
    write_q_.pop_front();
    if (!write_q_.empty()) write_next();
}

/////////////////////////////////////////////////////////
// AsyncWsServer
AsyncWsServer::AsyncWsServer(net::io_context& ioc, tcp::endpoint endpoint, const std::string& auth_secret)
: ioc_(ioc), acceptor_(ioc, endpoint), auth_secret_(auth_secret) {}

void AsyncWsServer::run() {
    accept_loop();
}

void AsyncWsServer::accept_loop() {
    acceptor_.async_accept([this](beast::error_code ec, tcp::socket socket){
        if (!ec) {
            auto session = std::make_shared<WsSession>(std::move(socket), this);
            session->start();
        } else {
            std::cerr << "accept error: " << ec.message() << std::endl;
        }
        // continue
        accept_loop();
    });
}

void AsyncWsServer::subscribe_client(const std::string& streamId, std::shared_ptr<WsSession> session) {
    std::lock_guard<std::mutex> lk(topic_mux_);
    topic_map_[streamId].insert(session);
}

void AsyncWsServer::unsubscribe_client(const std::string& streamId, std::shared_ptr<WsSession> session) {
    std::lock_guard<std::mutex> lk(topic_mux_);
    auto it = topic_map_.find(streamId);
    if (it != topic_map_.end()) {
        it->second.erase(session);
        if (it->second.empty()) topic_map_.erase(it);
    }
}

void AsyncWsServer::publish(const std::string& streamId, const std::string& payload) {
    std::lock_guard<std::mutex> lk(topic_mux_);
    auto it = topic_map_.find(streamId);
    if (it == topic_map_.end()) return;
    // copy set so we don't hold lock during deliver
    std::vector<std::shared_ptr<WsSession>> subscribers;
    for (auto &s : it->second) {
        if (auto ptr = s) subscribers.push_back(ptr);
    }
    for (auto &sess : subscribers) {
        sess->deliver(payload);
    }
}
