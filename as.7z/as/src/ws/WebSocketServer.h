#pragma once
#include <string>
#include <memory>
#include <set>
#include <mutex>

class WebSocketServer {
public:
    WebSocketServer(const std::string& host, int port);
    ~WebSocketServer();

    void start(); // start background thread
    void stop();
    void broadcast(const std::string& msg);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
