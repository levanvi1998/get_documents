#include "WebSocketServer.h"
#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <thread>
#include <iostream>

namespace beast = boost::beast;
namespace http = beast::http;
namespace websocket = beast::websocket;
namespace net = boost::asio;
using tcp = net::ip::tcp;

struct WebSocketServer::Impl {
    std::string host;
    int port;
    std::thread th;
    net::io_context ioc;
    std::set<std::shared_ptr<websocket::stream<beast::tcp_stream>>> clients;
    std::mutex mux;
    std::atomic<bool> running{false};

    Impl(const std::string& h, int p): host(h), port(p){}
};

WebSocketServer::WebSocketServer(const std::string& host, int port) : impl_(new Impl(host,port)) {}

WebSocketServer::~WebSocketServer(){ stop(); }

void WebSocketServer::start() {
    if (impl_->running) return;
    impl_->running = true;
    impl_->th = std::thread([this](){
        try {
            net::io_context& ioc = impl_->ioc;
            tcp::acceptor acceptor{ioc, {net::ip::make_address(impl_->host), static_cast<unsigned short>(impl_->port)}};
            std::cout << "WebSocketServer listening " << impl_->host << ":" << impl_->port << std::endl;
            while (impl_->running) {
                tcp::socket socket{ioc};
                acceptor.accept(socket);
                auto ws = std::make_shared<websocket::stream<beast::tcp_stream>>(std::move(socket));
                ws->accept();
                {
                    std::lock_guard<std::mutex> lk(impl_->mux);
                    impl_->clients.insert(ws);
                    std::cout << "WS client connected. total=" << impl_->clients.size() << std::endl;
                }
                // no per-client read loop: this is broadcast-only demo; production: handle reads and close events
            }
        } catch (const std::exception& e) {
            std::cerr << "WS server error: " << e.what() << std::endl;
        }
    });
}

void WebSocketServer::stop() {
    if (!impl_->running) return;
    impl_->running = false;
    if (impl_->th.joinable()) impl_->th.join();
}

void WebSocketServer::broadcast(const std::string& msg) {
    std::lock_guard<std::mutex> lk(impl_->mux);
    for (auto it = impl_->clients.begin(); it != impl_->clients.end();) {
        auto ws = *it;
        beast::error_code ec;
        ws->text(true);
        ws->write(net::buffer(msg), ec);
        if (ec) {
            std::cerr << "WS write error: " << ec.message() << " - removing client\n";
            it = impl_->clients.erase(it);
        } else ++it;
    }
}
