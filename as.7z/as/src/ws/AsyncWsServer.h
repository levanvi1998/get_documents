#pragma once
#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <mutex>
#include <deque>

namespace beast = boost::beast;
namespace websocket = beast::websocket;
namespace net = boost::asio;
using tcp = net::ip::tcp;

// forward
class AsyncWsServer;

class WsSession : public std::enable_shared_from_this<WsSession> {
public:
    WsSession(tcp::socket socket, AsyncWsServer* server);
    void start();
    void deliver(const std::string& msg); // called by server to push message to client

    std::string id(); // for debug

private:
    void do_accept();
    void read_loop();
    void on_read(beast::error_code ec, std::size_t bytes_transferred);
    void write_next();
    void on_write(beast::error_code ec, std::size_t bytes_transferred);
    void process_message(const std::string& s);

    websocket::stream<beast::tcp_stream> ws_;
    beast::flat_buffer buffer_;
    AsyncWsServer* server_;
    std::deque<std::string> write_q_;
    std::mutex write_mux_;

    bool authenticated_ = false;
    std::unordered_set<std::string> subscriptions_;
};

class AsyncWsServer {
public:
    AsyncWsServer(net::io_context& ioc, tcp::endpoint endpoint, const std::string& auth_secret);
    void run();
    void accept_loop();

    // subscription management
    void subscribe_client(const std::string& streamId, std::shared_ptr<WsSession> session);
    void unsubscribe_client(const std::string& streamId, std::shared_ptr<WsSession> session);

    // publish metadata to all subscribed clients
    void publish(const std::string& streamId, const std::string& payload);

private:
    net::io_context& ioc_;
    tcp::acceptor acceptor_;
    std::string auth_secret_;

    // topic -> sessions
    std::unordered_map<std::string, std::unordered_set<std::shared_ptr<WsSession>>> topic_map_;
    std::mutex topic_mux_;
};
