#include "app/AppConfig.h"
#include "ai/AIEngine.h"
#include "aws/S3Uploader.h"
#include "ws/WebSocketServer.h"
#include "core/PipelineManager.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <memory>
#include "httplib.h"

int main(int argc, char** argv) {
    // load minimal config (or hardcode)
    AppConfig cfg = AppConfig::load("config.json");

    // httplib::Server svr;

    // svr.Post("/start", [&](const httplib::Request& req, httplib::Response& res){
    //     auto out = mgr.startStream(req.body);
    //     res.set_content(out, "application/json");
    // });

    // svr.Post("/stop", [&](const httplib::Request& req, httplib::Response& res){
    //     auto out = mgr.stopStream(req.body);
    //     res.set_content(out, "application/json");
    // });

    auto ai = std::make_shared<AIEngine>(cfg.modelPath, 640, 640);
    auto ws = std::make_shared<WebSocketServer>(cfg.wsHost, cfg.wsPort);
    ws->start();
    auto s3 = std::make_shared<S3Uploader>(cfg.s3Bucket, cfg.s3Region);

    PipelineManager pm(ai, ws, s3);

    // Example: start two streams (replace with MediaMTX urls)
    pm.startStream("cam1", "rtmp://127.0.0.1:1935/live/cam1");
    pm.startStream("cam2", "rtmp://127.0.0.1:1935/live/cam2");

    std::cout << "System running. press ctrl+c to quit\n";
    while (true) std::this_thread::sleep_for(std::chrono::seconds(10));

    // std::cout << "C++ Manager listening on 0.0.0.0:8080\n";
    // svr.listen("0.0.0.0", 8080);
    return 0;
}
