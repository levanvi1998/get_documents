#include "GStreamerPipeline.h"
#include <iostream>
#include <cstring>
#include <gst/video/video.h>
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sstream>

GStreamerPipeline::GStreamerPipeline(const std::string& uri, const std::string& stream_id, ThreadSafeQueue<FrameItem>& q, SegmentCallback cb)
: uri_(uri), stream_id_(stream_id), queue_(q), segment_cb_(cb) {
    gst_init(nullptr, nullptr);
}

GStreamerPipeline::~GStreamerPipeline() {
    stop();
}

bool GStreamerPipeline::start() {
    if (pipeline_) return true;

    // build pipeline with tee + appsink + splitmuxsink
    // note: splitmuxsink will create files in ./segments/<streamname>/segment_%05d.mp4
    // we will set the location property programmatically using element's property
    // create per-stream segments directory: ./segments/<stream_id>
    std::string segments_root = "./segments";
    std::string segments_dir = segments_root + "/" + stream_id_;
    std::filesystem::create_directories(segments_dir);

    // Use uridecodebin to support rtmp/rtsp/uri
    std::string pipe =
        "uridecodebin uri=\"" + uri_ + "\" name=dec "
        "dec. ! videoconvert ! video/x-raw,format=BGR ! tee name=t "
        "t. ! queue ! appsink name=ai_sink sync=false max-buffers=2 drop=true "
        "t. ! queue ! videoconvert ! x264enc tune=zerolatency bitrate=2000 speed-preset=superfast ! "
        "mp4mux ! splitmuxsink name=sm sink_0::muxer=mp4mux location=" + segments_dir + "/segment_%05d.mp4 max-size-time=30000000000";

    GError* err = nullptr;
    pipeline_ = gst_parse_launch(pipe.c_str(), &err);
    if (!pipeline_) {
        if (err) { std::cerr << "Gst parse error: " << err->message << std::endl; g_error_free(err); }
        return false;
    }

    // get appsink
    appsink_ = gst_bin_get_by_name(GST_BIN(pipeline_), "ai_sink");
    if (!appsink_) {
        std::cerr << "Cannot find appsink element\n";
        gst_object_unref(pipeline_);
        pipeline_ = nullptr;
        return false;
    }
    GstAppSinkCallbacks callbacks{};
    callbacks.new_sample = on_new_sample;
    gst_app_sink_set_callbacks(GST_APP_SINK(appsink_), &callbacks, this, nullptr);

    // bus: listen for element messages from splitmuxsink
    bus_ = gst_element_get_bus(pipeline_);
    gst_bus_add_watch(bus_, [](GstBus* bus, GstMessage* msg, gpointer data) -> gboolean {
        GStreamerPipeline* self = static_cast<GStreamerPipeline*>(data);
        self->handle_bus_message(msg);
        return TRUE;
    }, this);

    gst_element_set_state(pipeline_, GST_STATE_PLAYING);
    std::cout << "[GstPipeline] started uri=" << uri_ << std::endl;
    return true;
}

void GStreamerPipeline::stop() {
    if (!pipeline_) return;
    gst_element_set_state(pipeline_, GST_STATE_NULL);
    if (appsink_) { gst_object_unref(appsink_); appsink_ = nullptr; }
    if (bus_) { gst_object_unref(bus_); bus_ = nullptr; }
    gst_object_unref(pipeline_);
    pipeline_ = nullptr;
    std::cout << "[GstPipeline] stopped uri=" << uri_ << std::endl;
}

GstFlowReturn GStreamerPipeline::on_new_sample(GstAppSink* sink, gpointer user_data) {
    GStreamerPipeline* self = static_cast<GStreamerPipeline*>(user_data);
    GstSample* sample = gst_app_sink_pull_sample(sink);
    if (!sample) return GST_FLOW_ERROR;
    self->handle_sample(sample);
    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

void GStreamerPipeline::handle_sample(GstSample* sample) {
    GstBuffer* buffer = gst_sample_get_buffer(sample);
    GstCaps* caps = gst_sample_get_caps(sample);
    GstStructure* s = gst_caps_get_structure(caps, 0);
    int width=0, height=0;
    gst_structure_get_int(s, "width", &width);
    gst_structure_get_int(s, "height", &height);

    GstMapInfo map;
    if (!gst_buffer_map(buffer, &map, GST_MAP_READ)) return;

    FrameItem fi;
    fi.width = width;
    fi.height = height;
    fi.pts = GST_BUFFER_PTS(buffer);
    fi.data.assign(map.data, map.data + map.size);

    // backpressure: keep small queue
    if (queue_.size() < 4) queue_.push(std::move(fi));

    gst_buffer_unmap(buffer, &map);
}

void GStreamerPipeline::handle_bus_message(GstMessage* msg) {
    if (!msg) return;
    if (GST_MESSAGE_TYPE(msg) == GST_MESSAGE_ELEMENT) {
        const GstStructure* s = gst_message_get_structure(msg);
        if (!s) return;
        const char* nm = gst_structure_get_name(s);
        // splitmuxsink posts element messages with name "splitmux" or structure fields
        // We inspect structure for "filename" or "filename" field (depends gst version)
        if (gst_structure_has_name(s, "splitmuxsink") || gst_structure_has_name(s, "splitmux")) {
            // try to extract filename/location reported by splitmuxsink
            const char* filename = gst_structure_get_string(s, "filename");
            const char* location = gst_structure_get_string(s, "location");
            const char* chosen = filename ? filename : location;
            if (chosen && segment_cb_) {
                // attempt to rename the completed segment into a timestamped file
                try {
                    std::filesystem::path orig(chosen);
                    std::filesystem::path parent = orig.parent_path();
                    if (parent.empty()) parent = std::filesystem::path(".");
                    std::string new_basename = make_timestamped_filename(orig.string());
                    std::filesystem::path dest = parent / new_basename;
                    // perform rename; if fails, fallback to original
                    std::error_code ec;
                    std::filesystem::rename(orig, dest, ec);
                    if (ec) {
                        // rename failed: log and forward original path
                        std::cerr << "[GstPipeline] segment rename failed: " << ec.message() << " - keeping original name\n";
                        segment_cb_(orig.string());
                    } else {
                        segment_cb_(dest.string());
                    }
                } catch (const std::exception& e) {
                    std::cerr << "[GstPipeline] exception renaming segment: " << e.what() << std::endl;
                    segment_cb_(std::string(chosen));
                }
            }
        }
        // Alternative: check for "splitmux-fragment" or any other known structure name
        if (gst_structure_has_name(s, "splitmux-fragment")) {
            const char* filename = gst_structure_get_string(s, "filename");
            if (filename && segment_cb_) {
                try {
                    std::filesystem::path orig(filename);
                    std::filesystem::path parent = orig.parent_path();
                    if (parent.empty()) parent = std::filesystem::path(".");
                    std::string new_basename = make_timestamped_filename(orig.string());
                    std::filesystem::path dest = parent / new_basename;
                    std::error_code ec;
                    std::filesystem::rename(orig, dest, ec);
                    if (ec) {
                        std::cerr << "[GstPipeline] fragment rename failed: " << ec.message() << "\n";
                        segment_cb_(orig.string());
                    } else {
                        segment_cb_(dest.string());
                    }
                } catch (const std::exception& e) {
                    std::cerr << "[GstPipeline] exception renaming fragment: " << e.what() << std::endl;
                    segment_cb_(std::string(filename));
                }
            }
        }
    }
    // other messages ignored
}

std::string GStreamerPipeline::make_timestamped_filename(const std::string& orig_path) const {
    // orig_path may be a full path; we use its extension but create a new basename
    std::filesystem::path p(orig_path);
    std::string ext = p.extension().string();
    // get current time with milliseconds
    using namespace std::chrono;
    auto now = system_clock::now();
    auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
    std::time_t t = system_clock::to_time_t(now);
    std::tm tm;
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    std::ostringstream ss;
    ss << stream_id_ << "_" << std::put_time(&tm, "%Y%m%d_%H%M%S") << '_' << std::setfill('0') << std::setw(3) << ms.count() << ext;
    return ss.str();
}
