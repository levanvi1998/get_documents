#pragma once
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <string>
#include <memory>
#include <functional>
#include "../util/ThreadSafeQueue.h"

// FrameItem giống trước
struct FrameItem {
    std::vector<uint8_t> data;
    int width;
    int height;
    int64_t pts;
};

class GStreamerPipeline {
public:
    // file_segment_cb: called when splitmuxsink finishes a segment (local_path)
    using SegmentCallback = std::function<void(const std::string& local_path)>;

    GStreamerPipeline(const std::string& uri, const std::string& stream_id, ThreadSafeQueue<FrameItem>& q, SegmentCallback cb);
    ~GStreamerPipeline();

    bool start();
    void stop();

private:
    static GstFlowReturn on_new_sample(GstAppSink* sink, gpointer user_data);
    static gboolean bus_call(GstBus* bus, GstMessage* msg, gpointer user_data);
    void handle_sample(GstSample* sample);
    void handle_bus_message(GstMessage* msg);

    // create a timestamped filename (uses stream_id_); returns new filename (basename)
    std::string make_timestamped_filename(const std::string& orig_path) const;

    std::string uri_;
    std::string stream_id_;
    ThreadSafeQueue<FrameItem>& queue_;
    SegmentCallback segment_cb_;

    GstElement* pipeline_ = nullptr;
    GstElement* appsink_ = nullptr;
    GstBus* bus_ = nullptr;
};
