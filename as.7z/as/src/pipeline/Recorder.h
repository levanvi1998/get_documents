#pragma once
#include <string>
#include <memory>
#include <functional>
#include "../aws/S3Uploader.h"

// Recorder minimal wrapper: invoked by StreamSession when starting pipeline
// It doesn't create pipeline, only holds streamId and S3 uploader and helps naming/policy.
class Recorder {
public:
    Recorder(const std::string& streamId, std::shared_ptr<S3Uploader> s3);
    ~Recorder();

    // Called by pipeline when a segment is ready
    void onSegmentReady(const std::string& localPath);

    // optional: rotate/delete policy
    void removeLocalAfterUpload(bool v) { remove_after_upload_ = v; }

private:
    std::string streamId_;
    std::shared_ptr<S3Uploader> s3_;
    bool remove_after_upload_ = false;
};
