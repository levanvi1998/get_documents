#include "Recorder.h"
#include <iostream>
#include <filesystem>

Recorder::Recorder(const std::string& streamId, std::shared_ptr<S3Uploader> s3)
: streamId_(streamId), s3_(s3) {}

Recorder::~Recorder(){}

void Recorder::onSegmentReady(const std::string& localPath) {
    std::cout << "[Recorder] segment ready: " << localPath << std::endl;
    // choose s3 key: streams/<streamId>/<basename>
    std::string base = std::filesystem::path(localPath).filename().string();
    std::string key = "streams/" + streamId_ + "/" + base;
    if (s3_) {
        bool ok = s3_->uploadFile(localPath, key);
        if (ok) {
            std::cout << "[Recorder] uploaded " << base << " -> s3://" << key << std::endl;
            if (remove_after_upload_) {
                std::error_code ec;
                std::filesystem::remove(localPath, ec);
                if (ec) std::cerr << "remove local segment failed: " << ec.message() << std::endl;
            }
        } else {
            std::cerr << "[Recorder] upload failed for " << localPath << std::endl;
            // upload retry policy left to S3Uploader (or external retry queue)
        }
    } else {
        std::cout << "[Recorder] S3 uploader not configured. segment at " << localPath << std::endl;
    }
}
