#pragma once
#include <mutex>
#include <condition_variable>
#include <deque>

template<typename T>
class ThreadSafeQueue {
public:
    ThreadSafeQueue() = default;
    ~ThreadSafeQueue() = default;

    void push(T&& v) {
        {
            std::lock_guard<std::mutex> lk(mtx_);
            dq_.push_back(std::move(v));
        }
        cv_.notify_one();
    }

    bool pop(T& out, int timeout_ms = 500) {
        std::unique_lock<std::mutex> lk(mtx_);
        if (timeout_ms <= 0) cv_.wait(lk, [&]{ return !dq_.empty(); });
        else {
            if (!cv_.wait_for(lk, std::chrono::milliseconds(timeout_ms), [&]{ return !dq_.empty(); }))
                return false;
        }
        out = std::move(dq_.front());
        dq_.pop_front();
        return true;
    }

    size_t size() {
        std::lock_guard<std::mutex> lk(mtx_);
        return dq_.size();
    }

    void clear() {
        std::lock_guard<std::mutex> lk(mtx_);
        dq_.clear();
    }
private:
    std::mutex mtx_;
    std::condition_variable cv_;
    std::deque<T> dq_;
};
