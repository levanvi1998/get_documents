#pragma once
#include <string>

struct AppConfig {
    std::string modelPath;
    std::string s3Bucket;
    std::string s3Region;
    std::string wsHost;
    int wsPort;

    static AppConfig load(const std::string& path);
};
