#include "AppConfig.h"
#include <nlohmann/json.hpp>
#include <fstream>

AppConfig AppConfig::load(const std::string& path) {
    std::ifstream f(path);
    nlohmann::json j = nlohmann::json::parse(f);

    AppConfig cfg;
    cfg.modelPath = j["modelPath"];
    cfg.s3Bucket  = j["s3Bucket"];
    cfg.s3Region  = j["s3Region"];
    cfg.wsHost    = j["wsHost"];
    cfg.wsPort    = j["wsPort"];

    return cfg;
}
