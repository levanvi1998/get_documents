const ws = new WebSocket("ws://localhost:9002");
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

ws.onmessage = e => {
    try {
        const meta = JSON.parse(e.data);
        // example: meta.ai may contain detections - adapt to your model
        console.log(meta);
        ctx.clearRect(0,0,canvas.width,canvas.height);
        if (meta.ai && meta.ai.detections) {
            meta.ai.detections.forEach(d => {
                ctx.strokeStyle = 'red';
                ctx.lineWidth = 2;
                ctx.strokeRect(d.bbox[0], d.bbox[1], d.bbox[2], d.bbox[3]);
                ctx.fillStyle = 'red';
                ctx.fillText(d.label + ' ' + d.conf, d.bbox[0], d.bbox[1]-4);
            });
        }
    } catch (err) {
        console.warn("invalid meta", err);
    }
};
